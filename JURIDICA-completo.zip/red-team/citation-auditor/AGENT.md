# Red team — Auditor de citações

## Objetivo

Verificar cada autoridade determinante na fonte oficial e impedir que referência incompleta ou incorreta chegue à versão final.

## Norma

Confira tipo, número, ano, ente, artigo, redação aplicável à data, vigência, alterações e URL.

## Precedente

Confira tribunal, órgão, classe, número, relatoria quando disponível, julgamento/publicação, inteiro teor, fundamento determinante, status e URL.

## Resultado

| ID | Proposição | Referência | Verificação | Problema | Correção | Fonte |
| --- | --- | --- | --- | --- | --- | --- |

Use `CONFIRMADO`, `A CONFIRMAR` ou `NÃO VERIFICADO`. Remova da fundamentação determinante tudo o que não puder ser confirmado.


# Red team — Parte contrária

## Objetivo

Atacar a análise principal como faria uma contraparte tecnicamente competente. Não invente fato ou autoridade.

## Testes

- competência, legitimidade, interesse e adequação da via;
- prescrição, decadência, preclusão e intempestividade;
- ausência, ilicitude, insuficiência ou contradição de prova;
- exceção legal, regra especial e conflito temporal;
- precedente contrário, distinção ou superação;
- falha de causalidade, dano, autoria, capacidade ou representação;
- inconsistência entre narrativa, fundamento, pedido e cálculo;
- efeito econômico, operacional ou reputacional omitido;
- alternativa menos onerosa ou mais provável.

## Saída

| Ataque | Base | Impacto | Resposta possível | Evidência faltante | Risco residual |
| --- | --- | --- | --- | --- | --- |

Ao final, informe se a tese permanece `FORTE`, `MODERADA`, `FRÁGIL`, `CONTROVERTIDA` ou `SEM BASE SUFICIENTE` e justifique eventual mudança.


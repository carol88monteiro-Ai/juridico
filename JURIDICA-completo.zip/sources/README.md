# Catálogo de fontes

`REGISTRY.yml` é um diretório de partida. Cada URL deve ser acessada e validada no momento da análise. O catálogo não substitui a verificação do texto, da vigência, do inteiro teor ou do status do precedente.

Para tribunal estadual, regional ou órgão local, use o diretório do CNJ e confirme domínio, competência e repositório oficial antes da pesquisa.


# Revisão contratual

## Identificação

- Documento e versão:
- Data:
- Partes e poderes:
- Objetivo econômico:
- Anexos recebidos:
- Jurisdição e lei aplicável:

## Sumário executivo

[Síntese dos riscos determinantes]

## Matriz

| Cláusula | Obrigação/efeito | Risco | Gravidade | Redação sugerida | Impacto da mudança |
| --- | --- | --- | --- | --- | --- |

## Dependências e pendências

- [PREENCHER]

## Pontos de negociação

- [PREENCHER]

## Aviso

Minuta sujeita à revisão de profissional habilitado e validação das premissas comerciais.


# Notificação extrajudicial — minuta

- Notificante: `[PREENCHER]`
- Notificado: `[PREENCHER]`
- Relação jurídica: `[PREENCHER]`
- Documento-base: `[PREENCHER]`

## Fatos

[Descrição objetiva e verificável]

## Fundamento

[Base contratual ou normativa confirmada]

## Providência requerida

[Conduta, prazo e forma de comprovação]

## Reserva de direitos

[Redação proporcional, sem ameaça indevida]

## Entrega

[Meio autorizado e evidência de recebimento]

> Revisar poderes, destinatário, prazo, estratégia e efeitos antes do envio.


# Minuta de peça jurídica

> Campos desconhecidos permanecem como `[PREENCHER]`. Não protocolar sem revisão profissional.

## Endereçamento

[PREENCHER]

## Processo e partes

[PREENCHER]

## Síntese e objetivo

[PREENCHER]

## Fatos comprovados

[PREENCHER — referenciar documentos]

## Questões jurídicas

[PREENCHER]

## Fundamentos verificados

[PREENCHER — incluir fonte oficial]

## Aplicação ao caso

[PREENCHER]

## Pedidos ou requerimentos

[PREENCHER — coerentes com fundamentação e poderes]

## Provas e anexos

[PREENCHER]

## Valor e cálculos

[PREENCHER — mostrar premissas]

## Fecho

[PREENCHER]


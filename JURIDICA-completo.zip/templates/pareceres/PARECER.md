# Parecer jurídico

## Ementa

[Tema, questão e conclusão em síntese]

## Consulta e escopo

[Objetivo, jurisdição, data de corte e limitações]

## Fatos e documentos

| Fato | Status | Prova | Fonte |
| --- | --- | --- | --- |

## Quesitos

1. [PREENCHER]

## Fundamentação

[Normas e precedentes confirmados, seguidos de aplicação]

## Tese contrária

[PREENCHER]

## Conclusão

[Resposta por quesito e força da tese]

## Riscos e próximos passos

[PREENCHER]

## Fontes oficiais

[URLs e datas de acesso]


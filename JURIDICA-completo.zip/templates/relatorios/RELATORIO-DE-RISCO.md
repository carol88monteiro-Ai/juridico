# Relatório de risco jurídico

## Decisão a apoiar

[PREENCHER]

## Escopo e data de corte

[PREENCHER]

## Sumário executivo

[PREENCHER]

## Matriz de risco

| ID | Evento | Causa | Consequência | Probabilidade | Impacto | Evidência | Controle | Ação |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |

## Cenários

- Base:
- Favorável:
- Adverso:

## Responsáveis, prazos e evidências

| Ação | Responsável | Prazo | Evidência de conclusão |
| --- | --- | --- | --- |

## Limitações

[PREENCHER]


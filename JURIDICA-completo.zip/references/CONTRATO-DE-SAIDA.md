# Contrato de saída

## Resposta curta

Conclusão; premissas determinantes; principal risco; ação recomendada; fonte oficial essencial.

## Análise completa

Use as doze seções do `SKILL.md`.

## Contrato

Entregue sumário executivo, matriz de cláusulas, riscos por gravidade, dependências, redações sugeridas e pontos de negociação. Não altere sentido econômico sem explicar.

## Peça

Use `templates/peticoes/PECA.md`. Não invente endereçamento, qualificação, número, valor, pedido, prova ou precedente. Mantenha `[PREENCHER]` para desconhecidos.

## Cálculo

Mostre fórmula, datas, índice, taxa, base, arredondamento e fonte. Sem índice oficial ou critério jurídico, não calcule valor definitivo.


# Fontes oficiais e hierarquia

Use `sources/REGISTRY.yml` como catálogo inicial, não como prova automática.

## Ordem de pesquisa

1. Texto constitucional e legislação no portal oficial competente.
2. Precedente, súmula, tema ou decisão no repositório do tribunal.
3. Ato normativo no órgão regulador ou diário oficial.
4. Documento institucional do ente competente.
5. Fonte secundária somente para contexto.

## Norma

Confirme título, número, ano, ente, artigo, redação vigente na data do fato, alterações, revogação, regulamentação, vigência diferida e transição.

## Precedente

Confirme tribunal, órgão julgador, classe e número, relatoria quando disponível, datas, inteiro teor, tese decidida, situação, eventual afetação, suspensão, modulação, superação ou distinção.

## Registro

Guarde URL direta e data de acesso. Se a fonte estiver indisponível, marque a referência como não confirmada.


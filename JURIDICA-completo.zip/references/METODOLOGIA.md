# Metodologia FIRAC-BR

## Entrada mínima

- objetivo e decisão a apoiar;
- papel do usuário no caso;
- local e datas relevantes;
- relação entre as partes;
- documentos disponíveis;
- processo, foro e fase, se existentes;
- prazo ou urgência;
- resultado pretendido.

## F — Fatos

| Fato | Status | Prova | Fonte | Impacto |
| --- | --- | --- | --- | --- |
| Descrição neutra | Comprovado, alegado, controvertido ou inferido | Documento ou testemunho | Usuário, arquivo ou fonte externa | Alto, médio ou baixo |

Não use “comprovado” sem indicar a prova. Não presuma autenticidade documental.

## I — Questões

Formule perguntas específicas e organize-as em: admissibilidade e competência; preliminares e prejudiciais; mérito; prova e ônus; tempo e prazos; tutela e execução; consequências econômicas e reputacionais.

## R — Regras

| Proposição | Autoridade | Vigência verificada? | Fonte oficial | Observação |
| --- | --- | --- | --- | --- |

Considere hierarquia, especialidade, lei no tempo e no espaço, transição, exceções e regulamentação.

## A — Aplicação

Para cada requisito: declare o requisito; indique fato e prova; explique o encaixe ou ausência; apresente exceção e contra-argumento; conclua apenas sobre o requisito.

## C — Conclusão

Informe força, incertezas, atos recomendados, prazos dependentes de confirmação e necessidade de revisão profissional.

## Validação em cinco dimensões

| Dimensão | Pergunta |
| --- | --- |
| Normativa | Existe norma vigente e aplicável? |
| Jurisprudencial | Há precedente pertinente e confirmado? |
| Fática | Os fatos satisfazem os requisitos? |
| Probatória | Há prova admissível e suficiente? |
| Processual | Via, foro, prazo e legitimidade são adequados? |


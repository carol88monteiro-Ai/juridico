#!/usr/bin/env python3
"""Gera, no stdout, um intake JSON vazio para um novo caso."""

from __future__ import annotations

import json


CASE = {
    "objetivo": None,
    "papel_do_usuario": None,
    "jurisdicao": {"pais": "Brasil", "estado": None, "municipio": None, "foro": None},
    "data_de_corte": None,
    "urgencia": {"existe": False, "prazo": None, "origem": None},
    "partes": [],
    "cronologia": [],
    "fatos": [],
    "documentos": [],
    "processo": {"existe": False, "numero": None, "fase": None},
    "questoes_juridicas": [],
    "restricoes": [],
}


if __name__ == "__main__":
    print(json.dumps(CASE, ensure_ascii=False, indent=2))


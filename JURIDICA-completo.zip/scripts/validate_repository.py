#!/usr/bin/env python3
"""Valida a estrutura e os metadados básicos do JURIDICA."""

from __future__ import annotations

import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]

REQUIRED = [
    "README.md",
    "AGENTS.md",
    "SKILL.md",
    "agents/openai.yaml",
    "orchestrator/managing-partner/SKILL.md",
    "skills/brasil/raciocinio-juridico/SKILL.md",
    "red-team/opposing-counsel/AGENT.md",
    "red-team/citation-auditor/AGENT.md",
    "sources/REGISTRY.yml",
]

AREAS = {
    "civil", "consumidor", "empresarial", "contratos", "trabalhista",
    "tributario", "previdenciario", "imobiliario", "familia", "sucessoes",
    "penal", "constitucional", "administrativo", "digital", "lgpd",
    "processual",
}


def frontmatter(path: Path) -> dict[str, str]:
    text = path.read_text(encoding="utf-8")
    match = re.match(r"^---\n(.*?)\n---\n", text, re.DOTALL)
    if not match:
        raise ValueError("frontmatter ausente")
    result: dict[str, str] = {}
    for line in match.group(1).splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            result[key.strip()] = value.strip().strip('"')
    return result


def main() -> int:
    errors: list[str] = []

    for relative in REQUIRED:
        if not (ROOT / relative).is_file():
            errors.append(f"arquivo obrigatório ausente: {relative}")

    found_areas = {
        p.parent.name
        for p in (ROOT / "skills" / "brasil").glob("*/SKILL.md")
        if p.parent.name != "raciocinio-juridico"
    }
    missing_areas = sorted(AREAS - found_areas)
    if missing_areas:
        errors.append("áreas ausentes: " + ", ".join(missing_areas))

    names: dict[str, Path] = {}
    for path in sorted(ROOT.rglob("SKILL.md")):
        try:
            data = frontmatter(path)
        except ValueError as exc:
            errors.append(f"{path.relative_to(ROOT)}: {exc}")
            continue
        name = data.get("name", "")
        description = data.get("description", "")
        if not re.fullmatch(r"[a-z0-9-]{1,63}", name):
            errors.append(f"{path.relative_to(ROOT)}: name inválido: {name!r}")
        if not description:
            errors.append(f"{path.relative_to(ROOT)}: description ausente")
        if name in names:
            errors.append(
                f"name duplicado {name!r}: {names[name].relative_to(ROOT)} e "
                f"{path.relative_to(ROOT)}"
            )
        names[name] = path
        text = path.read_text(encoding="utf-8")
        if re.search(r"(?im)^\s*(?:[-*]\s*)?(?:\[?TODO\]?|#\s*TODO)\b", text):
            errors.append(f"{path.relative_to(ROOT)}: placeholder TODO")

    for path in ROOT.rglob("*"):
        if path.is_file() and path.suffix.lower() in {".md", ".yml", ".yaml", ".py"}:
            try:
                path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                errors.append(f"arquivo não UTF-8: {path.relative_to(ROOT)}")

    if errors:
        print("VALIDAÇÃO REPROVADA")
        for error in errors:
            print(f"- {error}")
        return 1

    print(
        "VALIDAÇÃO APROVADA: "
        f"{len(names)} skills, {len(found_areas)} áreas brasileiras, "
        f"{sum(1 for p in ROOT.rglob('*') if p.is_file())} arquivos."
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())

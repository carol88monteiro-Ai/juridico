---
name: negociacao-juridica
description: Prepara e apoia negociações jurídicas com interesses, alternativas, limites, concessões, riscos e registro claro dos termos.
---

# negociacao-juridica

## Objetivo

Aumentar clareza e controle sem prometer acordo.

## Processo

1. Identifique partes, representantes e poderes.
2. Mapeie interesses, posições, alternativas e limites autorizados.
3. Defina temas, prioridades, concessões condicionadas e dependências.
4. Calcule cenários com premissas explícitas.
5. Teste termos contra riscos jurídicos e operacionais.
6. Registre acordo em linguagem objetiva, sujeito a validação e assinatura.

## Saída

Mapa de negociação, cenários, pauta, concessões e minuta de termos.

Obedeça ao `AGENTS.md`, ao protocolo de confiança e à revisão profissional prevista no projeto.


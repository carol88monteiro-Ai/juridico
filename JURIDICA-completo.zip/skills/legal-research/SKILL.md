---
name: pesquisa-juridica-br
description: Executa pesquisa legislativa, regulatória, jurisprudencial e institucional brasileira com estratégia de busca e registro de fontes.
---

# pesquisa-juridica-br

## Objetivo

Responder questão delimitada com fontes primárias atuais.

## Processo

1. Formule questão e subquestões.
2. Liste autoridades prováveis e termos de busca.
3. Pesquise primeiro fontes oficiais.
4. Confirme vigência, competência e temporalidade.
5. Registre resultados contrários e ausência relevante.
6. Sintetize sem extrapolar o conteúdo das fontes.

## Saída

Memorando de pesquisa com questão, resposta, fontes, citações, limitações e próximos passos.

Obedeça ao `AGENTS.md`, ao protocolo de confiança e à revisão profissional prevista no projeto.


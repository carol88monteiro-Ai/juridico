---
name: redacao-juridica-br
description: Elabora e revisa peças, pareceres, notificações e memorandos jurídicos brasileiros com estrutura, coerência, precisão e campos rastreáveis.
---

# redacao-juridica-br

## Objetivo

Converter análise validada em documento jurídico revisável.

## Processo

1. Escolha o gênero e o destinatário.
2. Use fatos e pedidos autorizados; desconhecidos ficam como [PREENCHER].
3. Estruture questões, fundamentos e aplicação.
4. Cite somente autoridade validada.
5. Mantenha coerência entre fundamentação, pedidos e anexos.
6. Faça revisão adversarial, de citações, números, nomes e datas.

## Saída

Minuta limpa, lista de campos pendentes e checklist de revisão profissional.

Obedeça ao `AGENTS.md`, ao protocolo de confiança e à revisão profissional prevista no projeto.


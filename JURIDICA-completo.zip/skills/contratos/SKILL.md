---
name: analise-contratual
description: Revisa contratos brasileiros, identifica riscos e inconsistências, compara versões e propõe redações alternativas sem ocultar efeitos econômicos.
---

# analise-contratual

## Objetivo

Entregar diagnóstico contratual e propostas negociáveis.

## Processo

1. Confirme partes, poderes, objetivo econômico, anexos e versão.
2. Extraia definições, obrigações, prazos, pagamentos, garantias e eventos de inadimplemento.
3. Cheque coerência interna, referências cruzadas e hierarquia documental.
4. Classifique riscos jurídicos, financeiros, operacionais, regulatórios e reputacionais.
5. Apresente redação atual, problema, consequência e sugestão.
6. Sinalize pontos que exigem especialista, cálculo ou validação externa.

## Saída

Resumo executivo, matriz de cláusulas, riscos, redações sugeridas e pauta de negociação.

Obedeça ao `AGENTS.md`, ao protocolo de confiança e à revisão profissional prevista no projeto.


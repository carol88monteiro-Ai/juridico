---
name: revisao-documental-juridica
description: Extrai, compara e revisa documentos jurídicos, preservando versão, contexto, dados ausentes e rastreabilidade de cada achado.
---

# revisao-documental-juridica

## Objetivo

Transformar documento em dados estruturados e riscos verificáveis.

## Processo

1. Identifique arquivo, versão, data, integridade e legibilidade.
2. Extraia partes, definições, datas, valores, obrigações e anexos.
3. Marque texto ilegível, ausente ou inconsistente.
4. Compare versões por alteração material, não apenas textual.
5. Vincule cada achado a página, cláusula ou seção.
6. Evite inferir conteúdo que não esteja no documento.

## Saída

Inventário documental, extração estruturada, diferenças, achados e pendências.

Obedeça ao `AGENTS.md`, ao protocolo de confiança e à revisão profissional prevista no projeto.


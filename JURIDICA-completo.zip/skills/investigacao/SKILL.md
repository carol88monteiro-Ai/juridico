---
name: investigacao-juridica
description: Organiza investigação documental lícita, preservando escopo, cadeia de custódia, privacidade, contraditório e separação entre fato e hipótese.
---

# investigacao-juridica

## Objetivo

Apurar fatos com método e sem fabricar ou contaminar prova.

## Processo

1. Defina mandato, base, escopo e responsáveis.
2. Preserve documentos, metadados e cadeia de custódia.
3. Crie cronologia e mapa de pessoas, eventos e fontes.
4. Planeje entrevistas sem indução ou promessa indevida.
5. Corrobore afirmações com fontes independentes.
6. Registre achados, hipóteses alternativas, limitações e encaminhamentos.

## Saída

Plano de investigação, cronologia, matriz de evidências e relatório factual.

Obedeça ao `AGENTS.md`, ao protocolo de confiança e à revisão profissional prevista no projeto.


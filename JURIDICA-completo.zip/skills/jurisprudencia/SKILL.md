---
name: jurisprudencia-br
description: Pesquisa, valida e sintetiza jurisprudência brasileira em fontes oficiais, incluindo precedentes contrários e aderência fática.
---

# jurisprudencia-br

## Objetivo

Transformar uma questão jurídica em panorama jurisprudencial rastreável.

## Processo

1. Defina questão, período e tribunais competentes.
2. Pesquise temas, súmulas, repetitivos, repercussão geral e julgados pertinentes.
3. Leia o inteiro teor quando a decisão for determinante.
4. Extraia fundamento determinante e contexto fático.
5. Registre corrente favorável, contrária e eventuais divergências.
6. Classifique cada resultado como CONFIRMADO, A CONFIRMAR ou NÃO VERIFICADO.

## Saída

Tabela de precedentes, síntese das correntes, aderência ao caso, lacunas e URLs oficiais.

Obedeça ao `AGENTS.md`, ao protocolo de confiança e à revisão profissional prevista no projeto.


---
name: due-diligence-juridica
description: Conduz due diligence jurídica baseada em escopo, materialidade, documentos, achados, red flags e limitações de verificação.
---

# due-diligence-juridica

## Objetivo

Identificar riscos que afetem decisão, preço, garantia ou fechamento.

## Processo

1. Defina transação, escopo, materialidade e data de corte.
2. Monte request list e controle de documentos.
3. Separe ausência documental de inexistência de risco.
4. Classifique achados por probabilidade e impacto.
5. Quantifique somente quando houver base e premissas.
6. Relacione achado a condição precedente, indenização, garantia ou remediação.

## Saída

Sumário executivo, red flags, matriz de achados, pendências e recomendações transacionais.

Obedeça ao `AGENTS.md`, ao protocolo de confiança e à revisão profissional prevista no projeto.


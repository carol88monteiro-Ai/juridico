---
name: direito-previdenciario-br
description: Analisa filiação, contribuições, benefícios, incapacidade, tempo, dependência e procedimentos previdenciários brasileiros.
---

# direito-previdenciario-br

## Escopo

- segurados e dependentes
- contribuições
- carência
- tempo
- incapacidade
- benefícios
- revisão
- processo administrativo e judicial

## Intake obrigatório

Confirme objetivo, papel do usuário, local, datas, partes, documentos, processo existente, fase, prazo e impacto. Leia o documento integral antes de opinar sobre cláusula, ato ou prova.

## Checklist de análise

- regime
- categoria
- período
- CNIS e documentos
- qualidade
- carência
- requisitos na data
- DER
- cálculo
- prescrição
- recurso
- competência

## Execução

1. Aplique o núcleo em `../raciocinio-juridico/SKILL.md`.
2. Verifique legislação vigente e fontes oficiais específicas.
3. Separe regra geral, exceções e requisitos cumulativos.
4. Relacione cada requisito aos fatos e às provas.
5. Pesquise orientação favorável e contrária no tribunal competente.
6. Indique riscos, lacunas, alternativas e próximos atos.

Não presuma competência, prazo, valor, documento, vínculo ou resultado. Acione o módulo processual quando houver procedimento judicial ou administrativo.


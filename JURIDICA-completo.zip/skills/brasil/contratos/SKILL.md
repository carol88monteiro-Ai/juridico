---
name: contratos-br
description: Analisa formação, validade, interpretação, execução, revisão, garantias e extinção de contratos no Direito brasileiro.
---

# contratos-br

## Escopo

- formação
- capacidade e representação
- objeto
- preço
- obrigações
- garantias
- inadimplemento
- revisão
- resolução e rescisão

## Intake obrigatório

Confirme objetivo, papel do usuário, local, datas, partes, documentos, processo existente, fase, prazo e impacto. Leia o documento integral antes de opinar sobre cláusula, ato ou prova.

## Checklist de análise

- partes
- poderes
- anexos
- definições
- prazos
- condições
- riscos
- penalidades
- responsabilidade
- força maior
- dados
- foro
- assinatura

## Execução

1. Aplique o núcleo em `../raciocinio-juridico/SKILL.md`.
2. Verifique legislação vigente e fontes oficiais específicas.
3. Separe regra geral, exceções e requisitos cumulativos.
4. Relacione cada requisito aos fatos e às provas.
5. Pesquise orientação favorável e contrária no tribunal competente.
6. Indique riscos, lacunas, alternativas e próximos atos.

Não presuma competência, prazo, valor, documento, vínculo ou resultado. Acione o módulo processual quando houver procedimento judicial ou administrativo.


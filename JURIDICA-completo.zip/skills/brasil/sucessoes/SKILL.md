---
name: direito-sucessoes-br
description: Analisa herança, inventário, testamento, partilha, meação, herdeiros, dívidas e planejamento sucessório no Brasil.
---

# direito-sucessoes-br

## Escopo

- abertura
- herdeiros
- meação
- testamento
- inventário
- partilha
- dívidas
- colação
- planejamento

## Intake obrigatório

Confirme objetivo, papel do usuário, local, datas, partes, documentos, processo existente, fase, prazo e impacto. Leia o documento integral antes de opinar sobre cláusula, ato ou prova.

## Checklist de análise

- data e último domicílio
- estado civil
- regime
- árvore familiar
- patrimônio
- dívidas
- testamento
- doações
- prazos
- tributos
- via judicial ou extrajudicial

## Execução

1. Aplique o núcleo em `../raciocinio-juridico/SKILL.md`.
2. Verifique legislação vigente e fontes oficiais específicas.
3. Separe regra geral, exceções e requisitos cumulativos.
4. Relacione cada requisito aos fatos e às provas.
5. Pesquise orientação favorável e contrária no tribunal competente.
6. Indique riscos, lacunas, alternativas e próximos atos.

Não presuma competência, prazo, valor, documento, vínculo ou resultado. Acione o módulo processual quando houver procedimento judicial ou administrativo.


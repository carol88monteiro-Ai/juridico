---
name: direito-civil-br
description: Analisa obrigações, responsabilidade civil, contratos, posse, propriedade e outros temas civis brasileiros.
---

# direito-civil-br

## Escopo

- obrigações
- responsabilidade civil
- pessoas e bens
- posse e propriedade
- direitos reais
- prescrição e decadência

## Intake obrigatório

Confirme objetivo, papel do usuário, local, datas, partes, documentos, processo existente, fase, prazo e impacto. Leia o documento integral antes de opinar sobre cláusula, ato ou prova.

## Checklist de análise

- relação jurídica
- fato gerador
- requisitos
- nexo e dano
- inadimplemento
- excludentes
- prescrição ou decadência
- prova
- tutela e efeitos

## Execução

1. Aplique o núcleo em `../raciocinio-juridico/SKILL.md`.
2. Verifique legislação vigente e fontes oficiais específicas.
3. Separe regra geral, exceções e requisitos cumulativos.
4. Relacione cada requisito aos fatos e às provas.
5. Pesquise orientação favorável e contrária no tribunal competente.
6. Indique riscos, lacunas, alternativas e próximos atos.

Não presuma competência, prazo, valor, documento, vínculo ou resultado. Acione o módulo processual quando houver procedimento judicial ou administrativo.


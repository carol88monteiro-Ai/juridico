---
name: direito-administrativo-br
description: Analisa atos, processos, servidores, contratos públicos, licitações, sanções e responsabilidade estatal no Brasil.
---

# direito-administrativo-br

## Escopo

- ato administrativo
- processo
- servidor
- contratação pública
- bens e serviços públicos
- polícia
- sanção
- improbidade
- responsabilidade

## Intake obrigatório

Confirme objetivo, papel do usuário, local, datas, partes, documentos, processo existente, fase, prazo e impacto. Leia o documento integral antes de opinar sobre cláusula, ato ou prova.

## Checklist de análise

- ente e órgão
- competência
- procedimento
- motivação
- contraditório
- prazo
- norma específica
- contrato ou edital
- prova
- recurso
- controle
- prescrição

## Execução

1. Aplique o núcleo em `../raciocinio-juridico/SKILL.md`.
2. Verifique legislação vigente e fontes oficiais específicas.
3. Separe regra geral, exceções e requisitos cumulativos.
4. Relacione cada requisito aos fatos e às provas.
5. Pesquise orientação favorável e contrária no tribunal competente.
6. Indique riscos, lacunas, alternativas e próximos atos.

Não presuma competência, prazo, valor, documento, vínculo ou resultado. Acione o módulo processual quando houver procedimento judicial ou administrativo.


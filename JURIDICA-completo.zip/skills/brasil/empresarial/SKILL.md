---
name: direito-empresarial-br
description: Analisa sociedades, governança, operações empresariais, títulos, insolvência e riscos jurídicos corporativos no Brasil.
---

# direito-empresarial-br

## Escopo

- sociedades
- governança
- poderes
- operações
- títulos
- recuperação e insolvência
- propriedade empresarial
- responsabilidade de administradores

## Intake obrigatório

Confirme objetivo, papel do usuário, local, datas, partes, documentos, processo existente, fase, prazo e impacto. Leia o documento integral antes de opinar sobre cláusula, ato ou prova.

## Checklist de análise

- tipo societário
- contrato ou estatuto
- poderes
- aprovações
- beneficiário
- passivos
- garantias
- conflitos
- registros
- efeitos tributários e regulatórios

## Execução

1. Aplique o núcleo em `../raciocinio-juridico/SKILL.md`.
2. Verifique legislação vigente e fontes oficiais específicas.
3. Separe regra geral, exceções e requisitos cumulativos.
4. Relacione cada requisito aos fatos e às provas.
5. Pesquise orientação favorável e contrária no tribunal competente.
6. Indique riscos, lacunas, alternativas e próximos atos.

Não presuma competência, prazo, valor, documento, vínculo ou resultado. Acione o módulo processual quando houver procedimento judicial ou administrativo.


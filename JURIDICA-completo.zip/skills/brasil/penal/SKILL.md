---
name: direito-penal-br
description: Analisa tipicidade, autoria, prova, cautelares, defesa, pena e processo penal brasileiro com atenção reforçada a direitos fundamentais.
---

# direito-penal-br

## Escopo

- tipicidade
- ilicitude
- culpabilidade
- concurso
- autoria
- prova
- cautelares
- procedimento
- recursos
- execução penal

## Intake obrigatório

Confirme objetivo, papel do usuário, local, datas, partes, documentos, processo existente, fase, prazo e impacto. Leia o documento integral antes de opinar sobre cláusula, ato ou prova.

## Checklist de análise

- fato e data
- lei no tempo
- competência
- condição de procedibilidade
- flagrante
- cadeia de custódia
- prova lícita
- prescrição
- cautelar
- defesa
- risco à liberdade

## Execução

1. Aplique o núcleo em `../raciocinio-juridico/SKILL.md`.
2. Verifique legislação vigente e fontes oficiais específicas.
3. Separe regra geral, exceções e requisitos cumulativos.
4. Relacione cada requisito aos fatos e às provas.
5. Pesquise orientação favorável e contrária no tribunal competente.
6. Indique riscos, lacunas, alternativas e próximos atos.

Não presuma competência, prazo, valor, documento, vínculo ou resultado. Acione o módulo processual quando houver procedimento judicial ou administrativo.


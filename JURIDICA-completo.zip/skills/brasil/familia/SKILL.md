---
name: direito-familia-br
description: Analisa casamento, união estável, alimentos, guarda, convivência, filiação e medidas familiares brasileiras.
---

# direito-familia-br

## Escopo

- estado civil
- regimes
- união estável
- dissolução
- alimentos
- guarda
- convivência
- filiação
- proteção

## Intake obrigatório

Confirme objetivo, papel do usuário, local, datas, partes, documentos, processo existente, fase, prazo e impacto. Leia o documento integral antes de opinar sobre cláusula, ato ou prova.

## Checklist de análise

- vínculo
- datas
- bens
- filhos
- melhor interesse
- renda e necessidade
- violência ou urgência
- competência
- segredo
- prova
- acordo
- tutela

## Execução

1. Aplique o núcleo em `../raciocinio-juridico/SKILL.md`.
2. Verifique legislação vigente e fontes oficiais específicas.
3. Separe regra geral, exceções e requisitos cumulativos.
4. Relacione cada requisito aos fatos e às provas.
5. Pesquise orientação favorável e contrária no tribunal competente.
6. Indique riscos, lacunas, alternativas e próximos atos.

Não presuma competência, prazo, valor, documento, vínculo ou resultado. Acione o módulo processual quando houver procedimento judicial ou administrativo.


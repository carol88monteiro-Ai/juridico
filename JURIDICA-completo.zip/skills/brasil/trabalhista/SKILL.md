---
name: direito-trabalhista-br
description: Analisa relações de trabalho e emprego, remuneração, jornada, saúde, rescisão, negociação coletiva e processo trabalhista no Brasil.
---

# direito-trabalhista-br

## Escopo

- vínculo
- contratação
- remuneração
- jornada
- férias e afastamentos
- saúde e segurança
- discriminação
- rescisão
- coletivo
- processo

## Intake obrigatório

Confirme objetivo, papel do usuário, local, datas, partes, documentos, processo existente, fase, prazo e impacto. Leia o documento integral antes de opinar sobre cláusula, ato ou prova.

## Checklist de análise

- período
- função real
- subordinação e autonomia
- registros
- norma coletiva
- parcelas
- jornada
- saúde
- estabilidade
- prescrição
- prova
- competência

## Execução

1. Aplique o núcleo em `../raciocinio-juridico/SKILL.md`.
2. Verifique legislação vigente e fontes oficiais específicas.
3. Separe regra geral, exceções e requisitos cumulativos.
4. Relacione cada requisito aos fatos e às provas.
5. Pesquise orientação favorável e contrária no tribunal competente.
6. Indique riscos, lacunas, alternativas e próximos atos.

Não presuma competência, prazo, valor, documento, vínculo ou resultado. Acione o módulo processual quando houver procedimento judicial ou administrativo.


---
name: direito-imobiliario-br
description: Analisa compra, venda, locação, condomínio, registro, incorporação, financiamento, posse e regularização imobiliária no Brasil.
---

# direito-imobiliario-br

## Escopo

- aquisição
- registro
- locação
- condomínio
- incorporação
- financiamento
- garantia
- posse
- usucapião
- urbanístico

## Intake obrigatório

Confirme objetivo, papel do usuário, local, datas, partes, documentos, processo existente, fase, prazo e impacto. Leia o documento integral antes de opinar sobre cláusula, ato ou prova.

## Checklist de análise

- matrícula atual
- titularidade
- ônus
- cadeia dominial
- posse
- contrato
- licenças
- tributos
- condomínio
- ocupação
- garantias
- prazos
- competência

## Execução

1. Aplique o núcleo em `../raciocinio-juridico/SKILL.md`.
2. Verifique legislação vigente e fontes oficiais específicas.
3. Separe regra geral, exceções e requisitos cumulativos.
4. Relacione cada requisito aos fatos e às provas.
5. Pesquise orientação favorável e contrária no tribunal competente.
6. Indique riscos, lacunas, alternativas e próximos atos.

Não presuma competência, prazo, valor, documento, vínculo ou resultado. Acione o módulo processual quando houver procedimento judicial ou administrativo.


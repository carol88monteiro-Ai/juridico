---
name: direito-tributario-br
description: Analisa tributos, obrigações acessórias, enquadramentos, autuações, cobrança e contencioso tributário brasileiro.
---

# direito-tributario-br

## Escopo

- competência tributária
- fato gerador
- sujeito
- base e alíquota
- benefícios
- obrigações acessórias
- fiscalização
- dívida ativa
- contencioso

## Intake obrigatório

Confirme objetivo, papel do usuário, local, datas, partes, documentos, processo existente, fase, prazo e impacto. Leia o documento integral antes de opinar sobre cláusula, ato ou prova.

## Checklist de análise

- ente
- tributo
- período
- regime
- legislação temporal
- lançamento
- decadência e prescrição
- pagamento
- compensação
- parcelamento
- garantia
- prova contábil

## Execução

1. Aplique o núcleo em `../raciocinio-juridico/SKILL.md`.
2. Verifique legislação vigente e fontes oficiais específicas.
3. Separe regra geral, exceções e requisitos cumulativos.
4. Relacione cada requisito aos fatos e às provas.
5. Pesquise orientação favorável e contrária no tribunal competente.
6. Indique riscos, lacunas, alternativas e próximos atos.

Não presuma competência, prazo, valor, documento, vínculo ou resultado. Acione o módulo processual quando houver procedimento judicial ou administrativo.


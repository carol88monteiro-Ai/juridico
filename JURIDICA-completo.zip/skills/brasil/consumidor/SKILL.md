---
name: direito-consumidor-br
description: Analisa relações de consumo, vícios, falhas de serviço, cobranças, negativação, publicidade e responsabilidade no Brasil.
---

# direito-consumidor-br

## Escopo

- fornecedor e consumidor
- produto e serviço
- vício e fato
- cobrança
- cadastro
- publicidade
- contratos de adesão
- plataformas

## Intake obrigatório

Confirme objetivo, papel do usuário, local, datas, partes, documentos, processo existente, fase, prazo e impacto. Leia o documento integral antes de opinar sobre cláusula, ato ou prova.

## Checklist de análise

- incidência do regime
- cadeia de fornecimento
- dever de informação
- vulnerabilidade
- responsabilidade
- excludentes
- prova
- solução administrativa
- dano e tutela

## Execução

1. Aplique o núcleo em `../raciocinio-juridico/SKILL.md`.
2. Verifique legislação vigente e fontes oficiais específicas.
3. Separe regra geral, exceções e requisitos cumulativos.
4. Relacione cada requisito aos fatos e às provas.
5. Pesquise orientação favorável e contrária no tribunal competente.
6. Indique riscos, lacunas, alternativas e próximos atos.

Não presuma competência, prazo, valor, documento, vínculo ou resultado. Acione o módulo processual quando houver procedimento judicial ou administrativo.


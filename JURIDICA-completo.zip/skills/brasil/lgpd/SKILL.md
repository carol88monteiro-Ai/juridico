---
name: lgpd-br
description: Analisa tratamento de dados pessoais, bases legais, direitos, contratos, incidentes e governança segundo a LGPD e regulação brasileira.
---

# lgpd-br

## Escopo

- agentes
- papéis
- bases legais
- finalidade
- transparência
- direitos
- contratos
- transferência
- segurança
- incidente
- governança

## Intake obrigatório

Confirme objetivo, papel do usuário, local, datas, partes, documentos, processo existente, fase, prazo e impacto. Leia o documento integral antes de opinar sobre cláusula, ato ou prova.

## Checklist de análise

- inventário
- categoria de dado
- titular
- finalidade
- base
- necessidade
- retenção
- compartilhamento
- operador
- segurança
- direitos
- incidente
- ANPD
- evidência

## Execução

1. Aplique o núcleo em `../raciocinio-juridico/SKILL.md`.
2. Verifique legislação vigente e fontes oficiais específicas.
3. Separe regra geral, exceções e requisitos cumulativos.
4. Relacione cada requisito aos fatos e às provas.
5. Pesquise orientação favorável e contrária no tribunal competente.
6. Indique riscos, lacunas, alternativas e próximos atos.

Não presuma competência, prazo, valor, documento, vínculo ou resultado. Acione o módulo processual quando houver procedimento judicial ou administrativo.


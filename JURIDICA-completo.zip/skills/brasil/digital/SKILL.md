---
name: direito-digital-br
description: Analisa contratos digitais, plataformas, prova eletrônica, incidentes, conteúdo, IA e responsabilidade no ambiente digital brasileiro.
---

# direito-digital-br

## Escopo

- plataformas
- contratos eletrônicos
- assinatura
- prova digital
- conteúdo
- incidentes
- segurança
- IA
- comércio eletrônico

## Intake obrigatório

Confirme objetivo, papel do usuário, local, datas, partes, documentos, processo existente, fase, prazo e impacto. Leia o documento integral antes de opinar sobre cláusula, ato ou prova.

## Checklist de análise

- atores
- fluxo técnico
- jurisdição
- termos vigentes
- logs
- integridade
- autoria
- consentimento
- dever de informação
- remoção
- preservação de prova
- regulação atual

## Execução

1. Aplique o núcleo em `../raciocinio-juridico/SKILL.md`.
2. Verifique legislação vigente e fontes oficiais específicas.
3. Separe regra geral, exceções e requisitos cumulativos.
4. Relacione cada requisito aos fatos e às provas.
5. Pesquise orientação favorável e contrária no tribunal competente.
6. Indique riscos, lacunas, alternativas e próximos atos.

Não presuma competência, prazo, valor, documento, vínculo ou resultado. Acione o módulo processual quando houver procedimento judicial ou administrativo.


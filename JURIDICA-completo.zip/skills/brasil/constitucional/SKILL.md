---
name: direito-constitucional-br
description: Analisa direitos fundamentais, repartição de competências, controle de constitucionalidade e organização do Estado brasileiro.
---

# direito-constitucional-br

## Escopo

- direitos fundamentais
- competências
- poderes
- controle
- federação
- políticas públicas
- remédios constitucionais

## Intake obrigatório

Confirme objetivo, papel do usuário, local, datas, partes, documentos, processo existente, fase, prazo e impacto. Leia o documento integral antes de opinar sobre cláusula, ato ou prova.

## Checklist de análise

- ato impugnado
- direito afetado
- legitimidade
- competência
- parâmetro constitucional
- reserva legal
- proporcionalidade
- precedente vinculante
- via
- efeitos

## Execução

1. Aplique o núcleo em `../raciocinio-juridico/SKILL.md`.
2. Verifique legislação vigente e fontes oficiais específicas.
3. Separe regra geral, exceções e requisitos cumulativos.
4. Relacione cada requisito aos fatos e às provas.
5. Pesquise orientação favorável e contrária no tribunal competente.
6. Indique riscos, lacunas, alternativas e próximos atos.

Não presuma competência, prazo, valor, documento, vínculo ou resultado. Acione o módulo processual quando houver procedimento judicial ou administrativo.


---
name: direito-processual-br
description: Analisa competência, partes, atos, prazos, prova, tutela, recursos, cumprimento e estratégia processual no Brasil.
---

# direito-processual-br

## Escopo

- jurisdição
- competência
- partes
- atos
- prazos
- prova
- tutela
- precedentes
- sentença
- recursos
- execução
- coisa julgada

## Intake obrigatório

Confirme objetivo, papel do usuário, local, datas, partes, documentos, processo existente, fase, prazo e impacto. Leia o documento integral antes de opinar sobre cláusula, ato ou prova.

## Checklist de análise

- ramo e rito
- foro
- fase
- pedidos
- valor
- legitimidade
- interesse
- intimação
- prazo
- preclusão
- ônus
- tutela
- recurso
- execução

## Execução

1. Aplique o núcleo em `../raciocinio-juridico/SKILL.md`.
2. Verifique legislação vigente e fontes oficiais específicas.
3. Separe regra geral, exceções e requisitos cumulativos.
4. Relacione cada requisito aos fatos e às provas.
5. Pesquise orientação favorável e contrária no tribunal competente.
6. Indique riscos, lacunas, alternativas e próximos atos.

Não presuma competência, prazo, valor, documento, vínculo ou resultado. Acione o módulo processual quando houver procedimento judicial ou administrativo.


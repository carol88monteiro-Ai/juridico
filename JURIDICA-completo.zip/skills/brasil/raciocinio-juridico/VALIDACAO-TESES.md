# Validação de teses

Avalie:

| Dimensão | Evidência necessária |
| --- | --- |
| Normativa | Norma vigente e aplicável |
| Jurisprudencial | Precedentes pertinentes, atuais e confirmados |
| Fática | Correspondência entre hipótese normativa e fatos |
| Probatória | Prova existente, admissível e suficiente |
| Processual | Via, foro, legitimidade, interesse e tempestividade |

## Classificação

- **FORTE:** as cinco dimensões sustentam a tese e o principal contra-argumento foi enfrentado.
- **MODERADA:** há base relevante, mas uma dependência material permanece.
- **FRÁGIL:** falta requisito, prova ou autoridade importante.
- **CONTROVERTIDA:** existem linhas decisórias relevantes em conflito.
- **SEM BASE SUFICIENTE:** não é possível sustentar a tese com os dados disponíveis.

Registre o elemento que mais poderia alterar a classificação.


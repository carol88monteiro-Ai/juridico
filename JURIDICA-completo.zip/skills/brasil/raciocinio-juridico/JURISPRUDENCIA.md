# Pesquisa jurisprudencial

1. Converta a questão jurídica em termos objetivos.
2. Identifique tribunal competente e eventual precedente vinculante.
3. Pesquise sinônimos, dispositivo e situação fática.
4. Priorize inteiro teor, decisões colegiadas e fontes oficiais.
5. Leia fundamentos determinantes, não apenas ementa.
6. Registre precedentes favoráveis e contrários.
7. Verifique atualidade, superação, modulação, afetação e distinção.
8. Classifique a confiança segundo `ANTI-ALUCINACAO.md`.

## Registro

| Campo | Conteúdo |
| --- | --- |
| Questão | Pergunta respondida |
| Tribunal/órgão | Origem da decisão |
| Identificador | Classe e número |
| Julgamento/publicação | Datas confirmadas |
| Tese | Síntese própria |
| Aderência | Similaridades e diferenças fáticas |
| Status | Confirmado, a confirmar ou não verificado |
| Fonte | URL oficial e acesso |


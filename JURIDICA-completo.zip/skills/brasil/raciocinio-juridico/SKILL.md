---
name: raciocinio-juridico-brasileiro
description: Estrutura fatos, questões, normas, aplicação, provas e conclusão em análises do Direito brasileiro; valida teses e impede citações jurídicas não verificadas.
---

# Raciocínio jurídico brasileiro

Leia `FIRAC-BR.md`, `ANTI-ALUCINACAO.md`, `VALIDACAO-TESES.md` e `JURISPRUDENCIA.md` quando a demanda exigir análise jurídica substantiva.

## Processo

1. Fixe data de corte, jurisdição e objetivo.
2. Separe fatos comprovados, alegados, controvertidos, inferidos e ausentes.
3. Decomponha o caso em questões jurídicas.
4. Identifique norma vigente e requisitos.
5. Relacione cada requisito ao fato e à prova.
6. Pesquise precedentes favoráveis e contrários.
7. Valide a tese em cinco dimensões.
8. Execute red team quando aplicável.
9. Classifique força e confiança.
10. Entregue fontes e limites.

Não confunda plausibilidade linguística com validade jurídica.


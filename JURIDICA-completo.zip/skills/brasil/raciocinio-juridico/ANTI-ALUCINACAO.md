# Protocolo anti-invenção jurídica

## CONFIRMADO

Use somente quando a fonte oficial foi acessada e os campos essenciais foram conferidos. Registre URL e data de acesso.

## A CONFIRMAR

Use quando a referência parece pertinente, mas falta validar algum campo ou o inteiro teor. Não a utilize sozinha para recomendar conduta definitiva.

## NÃO VERIFICADO

Use quando não houver base suficiente. Declare `dados insuficientes para verificar` e indique onde pesquisar.

## Nunca fazer

- inventar artigo, processo, tema, súmula, relator, data ou ementa;
- completar número incompleto por inferência;
- transformar resultado de busca em confirmação;
- afirmar vigência sem conferir;
- declarar orientação dominante com amostra insuficiente;
- citar fonte secundária como se fosse o ato oficial;
- omitir precedente vinculante contrário localizado.

## Auditoria mínima

Norma: título, número, ente, artigo, redação temporal e URL. Precedente: tribunal, órgão, classe/número, data, teor relevante, status e URL.


# FIRAC-BR

## Fatos

Extraia sujeitos, relação jurídica, eventos, datas, valores e documentos. Classifique o status de cada fato e preserve controvérsias.

## Questões

Formule perguntas autônomas sobre competência, legitimidade, interesse, tempo, mérito, prova, tutela, execução e consequências.

## Regras

Parta de norma superior, especial e vigente. Depois considere regulamentação e precedentes qualificados. Não salte da ementa para uma regra geral sem verificar fundamentos e contexto.

## Aplicação

Faça subsunção requisito a requisito. Explique por que o precedente se aplica ou se distingue. Enfrente argumentos relevantes contrários.

## Conclusão

Responda cada questão, indique força, risco, dependência probatória, alternativa e próximo ato. Não declare certeza maior do que a evidência permite.


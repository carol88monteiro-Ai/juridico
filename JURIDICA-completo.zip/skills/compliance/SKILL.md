---
name: compliance-juridico
description: Avalia obrigações legais, regulatórias, éticas e controles internos, produzindo mapa de risco e plano de remediação verificável.
---

# compliance-juridico

## Objetivo

Comparar requisitos aplicáveis aos controles existentes.

## Processo

1. Defina entidade, setor, localidades e atividade.
2. Identifique obrigações e autoridades competentes.
3. Mapeie políticas, responsáveis, evidências e controles.
4. Avalie desenho e evidência de operação do controle.
5. Registre lacunas, severidade, causa e consequência.
6. Proponha ação, responsável, prazo e evidência de encerramento.

## Saída

Matriz requisito-controle-evidência, riscos e plano de remediação.

Obedeça ao `AGENTS.md`, ao protocolo de confiança e à revisão profissional prevista no projeto.


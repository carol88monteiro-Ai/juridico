---
name: lex-rag-builder
description: Projeta base de recuperação jurídica com proveniência, versionamento, controle temporal, segmentação e avaliação de respostas.
---

# RAG jurídico

## Entrada

- corpus autorizado
- jurisdição
- tipos
- metadados
- atualização
- política de acesso
- casos de uso

## Processo

1. Confirme escopo, fonte dos dados, jurisdição e data de corte.
2. Aplique `skills/brasil/raciocinio-juridico/SKILL.md`.
3. Preserve localização e proveniência de cada informação.
4. Marque dados ausentes, ilegíveis, controvertidos ou não verificados.
5. Faça controle de qualidade específico antes da entrega.

## Saída

- arquitetura
- esquema
- ingestão
- chunks
- metadados
- recuperação
- citações
- avaliação
- governança

Obedeça ao `AGENTS.md`. Não execute ato externo nem apresente minuta como documento final sem revisão profissional.


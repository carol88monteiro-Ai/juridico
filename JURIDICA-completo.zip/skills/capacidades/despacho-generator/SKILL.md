---
name: despacho-generator
description: Gera minuta de despacho adequada à fase informada, usando apenas dados, prazos e fundamentos confirmados.
---

# Minuta de despacho

## Entrada

- processo
- fase
- último ato
- pedido pendente
- norma
- providência pretendida

## Processo

1. Confirme escopo, fonte dos dados, jurisdição e data de corte.
2. Aplique `skills/brasil/raciocinio-juridico/SKILL.md`.
3. Preserve localização e proveniência de cada informação.
4. Marque dados ausentes, ilegíveis, controvertidos ou não verificados.
5. Faça controle de qualidade específico antes da entrega.

## Saída

- minuta concisa
- comandos claros
- destinatários
- prazo confirmado ou [PREENCHER]
- checklist

Obedeça ao `AGENTS.md`. Não execute ato externo nem apresente minuta como documento final sem revisão profissional.


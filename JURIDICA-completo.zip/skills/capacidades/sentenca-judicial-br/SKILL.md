---
name: sentenca-judicial-br
description: Gera minuta de sentença brasileira a partir de fatos, pedidos, defesas, provas e fontes confirmadas, com estrutura compatível com o procedimento aplicável.
---

# Minuta de sentença brasileira

## Entrada

- mapa de fatos e questões
- pedidos e defesas
- provas
- requisitos procedimentais
- normas e precedentes confirmados

## Processo

1. Confirme escopo, fonte dos dados, jurisdição e data de corte.
2. Aplique `skills/brasil/raciocinio-juridico/SKILL.md`.
3. Preserve localização e proveniência de cada informação.
4. Marque dados ausentes, ilegíveis, controvertidos ou não verificados.
5. Faça controle de qualidade específico antes da entrega.

## Saída

- relatório sintético
- questões
- fundamentação analítica
- enfrentamento de argumentos relevantes
- dispositivo coerente
- campos pendentes

Obedeça ao `AGENTS.md`. Não execute ato externo nem apresente minuta como documento final sem revisão profissional.


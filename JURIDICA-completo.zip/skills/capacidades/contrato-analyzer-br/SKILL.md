---
name: contrato-analyzer-br
description: Analisa contrato brasileiro por cláusula, coerência, risco, lacunas, obrigações e efeitos econômicos, propondo redações alternativas.
---

# Analisador contratual brasileiro

## Entrada

- contrato integral
- anexos
- versão
- objetivo
- posição do cliente
- pontos negociáveis

## Processo

1. Confirme escopo, fonte dos dados, jurisdição e data de corte.
2. Aplique `skills/brasil/raciocinio-juridico/SKILL.md`.
3. Preserve localização e proveniência de cada informação.
4. Marque dados ausentes, ilegíveis, controvertidos ou não verificados.
5. Faça controle de qualidade específico antes da entrega.

## Saída

- sumário
- matriz
- riscos
- inconsistências
- redações
- pontos de negociação
- pendências

Obedeça ao `AGENTS.md`. Não execute ato externo nem apresente minuta como documento final sem revisão profissional.


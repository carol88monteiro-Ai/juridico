---
name: tese-juridica-validator
description: Testa tese jurídica brasileira nas dimensões normativa, jurisprudencial, fática, probatória e processual, incluindo contratese.
---

# Validação de tese

## Entrada

- proposição exata
- fatos
- provas
- norma
- precedentes
- via e prazo

## Processo

1. Confirme escopo, fonte dos dados, jurisdição e data de corte.
2. Aplique `skills/brasil/raciocinio-juridico/SKILL.md`.
3. Preserve localização e proveniência de cada informação.
4. Marque dados ausentes, ilegíveis, controvertidos ou não verificados.
5. Faça controle de qualidade específico antes da entrega.

## Saída

- classificação
- suporte por dimensão
- ataques
- evidência faltante
- condição para mudança de conclusão

Obedeça ao `AGENTS.md`. Não execute ato externo nem apresente minuta como documento final sem revisão profissional.


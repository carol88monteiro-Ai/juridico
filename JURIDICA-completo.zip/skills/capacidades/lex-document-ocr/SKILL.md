---
name: lex-document-ocr
description: Orienta extração de texto e estrutura de PDFs ou imagens jurídicos, preservando páginas, incerteza, campos ilegíveis e integridade.
---

# OCR jurídico

## Entrada

- arquivo
- tipo
- páginas
- idioma
- qualidade
- objetivo de extração

## Processo

1. Confirme escopo, fonte dos dados, jurisdição e data de corte.
2. Aplique `skills/brasil/raciocinio-juridico/SKILL.md`.
3. Preserve localização e proveniência de cada informação.
4. Marque dados ausentes, ilegíveis, controvertidos ou não verificados.
5. Faça controle de qualidade específico antes da entrega.

## Saída

- texto por página
- campos estruturados
- marcações de baixa confiança
- inventário
- relatório de legibilidade

Obedeça ao `AGENTS.md`. Não execute ato externo nem apresente minuta como documento final sem revisão profissional.


---
name: jurisprudencia-miner
description: Pesquisa e organiza precedentes brasileiros em fonte oficial com controle de aderência fática, autoridade, atualidade e confiança.
---

# Mineração de jurisprudência

## Entrada

- questão jurídica
- fatos-chave
- tribunal
- período
- norma
- termos e sinônimos

## Processo

1. Confirme escopo, fonte dos dados, jurisdição e data de corte.
2. Aplique `skills/brasil/raciocinio-juridico/SKILL.md`.
3. Preserve localização e proveniência de cada informação.
4. Marque dados ausentes, ilegíveis, controvertidos ou não verificados.
5. Faça controle de qualidade específico antes da entrega.

## Saída

- tabela de precedentes favoráveis e contrários
- fundamentos
- distinções
- status de verificação
- URLs

Obedeça ao `AGENTS.md`. Não execute ato externo nem apresente minuta como documento final sem revisão profissional.


---
name: dje-monitor
description: Extrai publicações de diários oficiais e identifica atos, destinatários e possíveis prazos, sem calcular termo final sem calendário e regra confirmados.
---

# Monitoramento de diário oficial

## Entrada

- arquivo ou texto oficial
- diário
- edição
- data
- órgão
- partes e processo

## Processo

1. Confirme escopo, fonte dos dados, jurisdição e data de corte.
2. Aplique `skills/brasil/raciocinio-juridico/SKILL.md`.
3. Preserve localização e proveniência de cada informação.
4. Marque dados ausentes, ilegíveis, controvertidos ou não verificados.
5. Faça controle de qualidade específico antes da entrega.

## Saída

- publicações estruturadas
- ato
- data
- possível consequência
- prazo a confirmar
- fonte e integridade

Obedeça ao `AGENTS.md`. Não execute ato externo nem apresente minuta como documento final sem revisão profissional.


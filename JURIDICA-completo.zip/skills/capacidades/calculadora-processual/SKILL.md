---
name: calculadora-processual
description: Estrutura e executa cálculos jurídicos com fórmulas, datas, índices e fontes explícitas, recusando resultados definitivos sem parâmetros oficiais.
---

# Cálculos jurídicos

## Entrada

- principal
- eventos
- datas
- índice
- juros
- multa
- honorários
- pagamentos
- regra de arredondamento

## Processo

1. Confirme escopo, fonte dos dados, jurisdição e data de corte.
2. Aplique `skills/brasil/raciocinio-juridico/SKILL.md`.
3. Preserve localização e proveniência de cada informação.
4. Marque dados ausentes, ilegíveis, controvertidos ou não verificados.
5. Faça controle de qualidade específico antes da entrega.

## Saída

- memória de cálculo
- tabela por período
- fórmulas
- fontes
- premissas
- divergências e ressalvas

Obedeça ao `AGENTS.md`. Não execute ato externo nem apresente minuta como documento final sem revisão profissional.


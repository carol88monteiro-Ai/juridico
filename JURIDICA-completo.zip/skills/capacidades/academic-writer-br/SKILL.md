---
name: academic-writer-br
description: Apoia pesquisa e redação acadêmica jurídica brasileira com problema, método, referências rastreáveis e normas editoriais informadas.
---

# Escrita acadêmica jurídica

## Entrada

- pergunta
- hipótese
- método
- corpus
- instituição ou periódico
- norma bibliográfica

## Processo

1. Confirme escopo, fonte dos dados, jurisdição e data de corte.
2. Aplique `skills/brasil/raciocinio-juridico/SKILL.md`.
3. Preserve localização e proveniência de cada informação.
4. Marque dados ausentes, ilegíveis, controvertidos ou não verificados.
5. Faça controle de qualidade específico antes da entrega.

## Saída

- projeto
- estrutura
- revisão
- texto autoral
- citações conferíveis
- referências
- limitações

Obedeça ao `AGENTS.md`. Não execute ato externo nem apresente minuta como documento final sem revisão profissional.


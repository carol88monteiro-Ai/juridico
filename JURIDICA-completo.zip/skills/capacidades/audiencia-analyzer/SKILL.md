---
name: audiencia-analyzer
description: Analisa transcrição ou registro de audiência, separando falas, fatos, contradições, admissões, objeções e pontos de prova.
---

# Análise de audiência

## Entrada

- mídia ou transcrição
- participantes
- contexto
- ata
- questões controvertidas

## Processo

1. Confirme escopo, fonte dos dados, jurisdição e data de corte.
2. Aplique `skills/brasil/raciocinio-juridico/SKILL.md`.
3. Preserve localização e proveniência de cada informação.
4. Marque dados ausentes, ilegíveis, controvertidos ou não verificados.
5. Faça controle de qualidade específico antes da entrega.

## Saída

- linha do tempo
- síntese por depoente
- contradições internas e externas
- trechos localizados
- limitações

Obedeça ao `AGENTS.md`. Não execute ato externo nem apresente minuta como documento final sem revisão profissional.


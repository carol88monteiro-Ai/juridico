---
name: conciliacao-assistant
description: Prepara negociação e minuta de acordo com interesses, alternativas, intervalos autorizados e efeitos jurídicos verificados.
---

# Conciliação

## Entrada

- partes e poderes
- pedidos
- valores
- riscos
- alternativas
- limites
- condições

## Processo

1. Confirme escopo, fonte dos dados, jurisdição e data de corte.
2. Aplique `skills/brasil/raciocinio-juridico/SKILL.md`.
3. Preserve localização e proveniência de cada informação.
4. Marque dados ausentes, ilegíveis, controvertidos ou não verificados.
5. Faça controle de qualidade específico antes da entrega.

## Saída

- mapa de interesses
- cenários
- proposta
- concessões condicionadas
- minuta
- obrigações e encerramento

Obedeça ao `AGENTS.md`. Não execute ato externo nem apresente minuta como documento final sem revisão profissional.


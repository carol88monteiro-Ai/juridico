---
name: peticao-analyzer
description: Analisa petições, contestações, réplicas, recursos e manifestações, extraindo causas, argumentos, pedidos, provas, defesas e pendências.
---

# Análise de petições

## Entrada

- tipo de peça
- versão integral
- fase
- partes
- pedidos
- fundamentos
- provas
- preliminares
- prazos

## Processo

1. Confirme escopo, fonte dos dados, jurisdição e data de corte.
2. Aplique `skills/brasil/raciocinio-juridico/SKILL.md`.
3. Preserve localização e proveniência de cada informação.
4. Marque dados ausentes, ilegíveis, controvertidos ou não verificados.
5. Faça controle de qualidade específico antes da entrega.

## Saída

- mapa CAPPD
- cronologia
- pedidos versus defesas
- fatos incontroversos e controvertidos
- falhas
- providências

Obedeça ao `AGENTS.md`. Não execute ato externo nem apresente minuta como documento final sem revisão profissional.


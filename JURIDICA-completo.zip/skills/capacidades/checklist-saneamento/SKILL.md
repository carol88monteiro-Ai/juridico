---
name: checklist-saneamento
description: Organiza questões processuais e de mérito, fatos controvertidos, provas e ônus para apoiar minuta de saneamento.
---

# Saneamento processual

## Entrada

- petição
- defesa
- réplica
- decisões
- pedidos de prova
- fase
- rito

## Processo

1. Confirme escopo, fonte dos dados, jurisdição e data de corte.
2. Aplique `skills/brasil/raciocinio-juridico/SKILL.md`.
3. Preserve localização e proveniência de cada informação.
4. Marque dados ausentes, ilegíveis, controvertidos ou não verificados.
5. Faça controle de qualidade específico antes da entrega.

## Saída

- pendências
- questões
- fatos
- provas
- distribuição do ônus
- calendário
- minuta revisável

Obedeça ao `AGENTS.md`. Não execute ato externo nem apresente minuta como documento final sem revisão profissional.

